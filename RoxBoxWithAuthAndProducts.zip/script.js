function register(event) {
  event.preventDefault();
  const email = document.getElementById("email").value;
  const password = document.getElementById("password").value;
  localStorage.setItem("userEmail", email);
  document.getElementById("auth-status").innerText = "مرحبًا " + email + "!";
}
